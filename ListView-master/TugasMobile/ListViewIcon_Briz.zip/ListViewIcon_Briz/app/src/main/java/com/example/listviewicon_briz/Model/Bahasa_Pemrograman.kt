package com.example.listviewicon_briz.Model

class Bahasa_Pemrograman {
    var name: String = ""
    var detail: String = ""
    var poster: Int = 0
}